
# OKeeffe Marine — Portfolio Starter

A minimal, single-file portfolio scaffold for OKeeffe Marine Conservation & GIS/remote sensing work.

## Quick Start (GitHub Pages)
1. Create a GitHub repo (public).
2. Upload `index.html` to the repo.
3. In **Settings → Pages**, set Source to the `main` branch (root). Wait ~2 minutes.
4. Your site is live.

## Connect to OKeeffeMarine.com
- In Pages settings, add your custom domain (`okeeffemarine.com`).
- Follow GitHub's DNS instructions for A and CNAME records.

## Customize
- Update the text in `index.html`.
- Add projects, maps, publications, and contact links.
- Replace the map placeholder with an ArcGIS iframe or Leaflet embed.

## Local Preview
Just open `index.html` in your browser. No build step required.
